---
name: xuanhuan-skill
description: 玄幻漫剧创作技能包。执行大纲、人物、目录、章节的专业创作，基于玄幻漫剧创作法则和视觉化快节奏的写作风格生成高质量漫剧内容。
---

# 玄幻漫剧创作 Skill

[技能说明]
    专业的玄幻漫剧创作技能包，覆盖故事构思、人物塑造、章节规划、正文写作、内容修订全流程。根据不同创作阶段，读取对应的创作资源并生成符合玄幻漫剧规范的内容。

[文件结构]
    .claude/skills/xuanhuan-skill/
    ├── SKILL.md                               # 本文件（技能包核心配置）
    ├── outline-method.md                      # 大纲创作方法论（60集标准，含人物塑造指导）
    ├── output-style.md                        # 写作风格（含章节创作方法）
    ├── examples/
    │   ├── outline-example.md                 # 大纲示例
    │   ├── character-example.md               # 人物示例
    │   ├── catalog-example.md               # 章节目录示例    
    │   └── chapter-example.md                 # 章节示例
    └── templates/                             # 文档结构模板（通用）
        ├── outline-template.md                # 大纲文档格式模板
        ├── character-template.md              # 人物小传格式模板
        ├── chapter-index-template.md          # 章节目录格式模板
        └── chapter-template.md                # 章节正文格式模板

[核心能力]
    - **创作阶段理解**：识别当前处于大纲、人物、目录、章节创作还是内容修订阶段
    - **资源整合**：读取模板、方法论、风格、示例等多维度资源
    - **专业创作**：基于资源和上下文创作符合玄幻漫剧规范的内容
    - **内容修订**：根据反馈意见或aligner检查结果进行精准修改
    - **风格把控**：确保创作内容符合玄幻漫剧的视觉化、快节奏写作风格
    - **模板遵循**：严格按照模板格式生成文档结构
    - **上下文理解**：理解已有文档内容，确保创作连贯性
    - **节奏控制**：确保爽点密集、节奏极快、悬念强制的漫剧特性

[执行流程]
    第一步：理解创作需求
        识别当前创作阶段：
        - 如果在讨论故事大纲或outline.md不存在 → 大纲创作阶段
        - 如果在讨论人物或刚执行/character → 人物创作阶段
        - 如果在讨论章节规划或刚执行/catalog → 目录创作阶段（60集分集大纲）
        - 如果在创作章节正文或刚执行/write → 章节创作阶段
        - 如果用户提出修改意见或xuanhuan-aligner返回FAIL → 内容修订阶段

    第二步：读取创作资源
        **大纲创作阶段**：
            1. 读取 templates/outline-template.md（文档格式模板）
            2. 读取 outline-method.md（玄幻漫剧大纲创作方法论60集标准，含人物塑造指导）
            3. 读取 output-style.md（玄幻漫剧写作风格）
            4. 读取 examples/outline-example.md（玄幻漫剧大纲示例）
            5. 从对话历史获取用户提供的核心创意信息
        
        **人物创作阶段**：
            1. 读取 outline.md（了解故事背景和设定）
            2. 读取 templates/character-template.md（文档格式模板）
            3. 读取 outline-method.md（玄幻漫剧人物塑造指导部分）
            4. 读取 output-style.md（玄幻漫剧写作风格）
            5. 读取 examples/character-example.md（玄幻漫剧人物示例）
        
        **目录创作阶段**：
            1. 读取 outline.md 和 character.md（了解故事和人物）
            2. 读取 templates/chapter-index-template.md（文档格式模板）
            3. 读取 outline-method.md（玄幻漫剧60集三幕式结构规划方法）
            4. 读取 output-style.md（玄幻漫剧写作风格）
            5. 读取 examples/catalog-example.md（玄幻漫剧章节目录示例）            
        
        **章节创作阶段**：
            1. 读取 outline.md、character.md、chapter_index.md（全部上下文）
            2. 读取 chapters/Episode-XX.md （全部章节正文，如有）
            3. 读取 outline-method.md（玄幻漫剧创作方法论，最重要）
            4. 读取 output-style.md（玄幻漫剧写作风格和章节创作方法）
            5. 读取 templates/chapter-template.md（文档格式模板）
            6. 读取 examples/chapter-example.md（玄幻漫剧章节示例）
            7. 从outline.md和chapter_index.md中获取当前批次5集的规划内容
        
        **内容修订阶段**：
            1. 读取被修改文档的当前版本（outline.md/character.md/chapter_index.md/chapters/Episode-XX.md）
            2. 读取相关基准文档（如修改章节正文时，需读取outline.md、character.md、chapter_index.md）
            3. 获取修改意见来源：
                - 用户直接提出的修改意见
                - xuanhuan-aligner返回的FAIL反馈和具体问题清单
            4. 读取对应的方法论和风格文档：
                - 修改大纲：读取 outline-method.md、output-style.md
                - 修改人物：读取 outline-method.md（人物塑造部分）、output-style.md
                - 修改目录：读取 outline-method.md、output-style.md
                - 修改章节：读取 outline-method.md（最重要）、output-style.md
            5. 读取对应的模板文档，确保修改后仍符合格式要求

    第三步：执行专业创作
        **大纲创作**：
            基于用户提供的信息和读取的资源：
            - 严格按照 templates/outline-template.md 的格式结构
            - 遵循 outline-method.md 的玄幻漫剧创作方法论（60集标准）
            - 应用 output-style.md 的视觉化、快节奏写作风格
            - 参考 examples/outline-example.md 的示例
            - 生成包含以下内容的完整大纲：
                • 漫剧信息（剧名、类型：玄幻漫剧、故事调性、60集规格）
                • 核心梗概（一句话）
                • 导语（150-200字，包含废材开局、金手指觉醒、力量悬念）
                • 故事大纲（采用三幕式60集结构，按第1-20集、第21-45集、第46-60集划分）
                • 主要人物（简要列出主角和关键配角）
                • 爽点分布规划（第20/40/60集超级爽点，第10/30/50集大爽点）
                • 境界体系（清晰的修炼等级和主角所在集数）
        
        **人物创作**：
            基于outline.md的故事设定和读取的资源：
            - 严格按照 templates/character-template.md 的格式结构
            - 遵循 outline-method.md 中的玄幻漫剧人物塑造指导
            - 应用 output-style.md 的简洁有力写作风格
            - 参考 examples/character-example.md 的示例
            - 生成包含以下内容的人物小传：
                • 主角（境界/身份+处境/背景+性格标签+外貌特征，150-200字）
                • 炮灰反派（每个50-80字，按出场集数分批）
                • 未婚妻/追求者（如有，80-100字）
                • 宗门长老/师尊（60-80字，简笔带过）
                • 兄弟/跟班（如有，60-80字，最多1个）
                • 最终boss（100-120字，第40-60集出现）
                • 其他角色（如有，每个30-50字）
            - 确保人物工具人化，推动情节
        
        **目录创作**：
            基于outline.md和character.md的设定和读取的资源：
            - 严格按照 templates/chapter-index-template.md 的格式结构
            - 遵循 outline-method.md 的玄幻漫剧60集三幕式结构方法
            - 应用 output-style.md 的写作风格
            - 参考 examples/catalog-example.md 的示例            
            - 生成固定60集的章节目录，采用三幕式结构
            - 每集包含：集标题 + 一句话剧情简介（体现爽点推进）
            - 确保三幕布局合理（第1-20集、第21-45集、第46-60集）
            - 确保爽点分布清晰（第10/20/30/40/50/60集为关键节点）
        
        **章节创作**：
            基于全部上下文文档和读取的资源：
            - 严格遵循 outline-method.md 的玄幻漫剧创作方法论（最重要）
            - 严格按照 templates/chapter-template.md 的格式结构
            - 严格应用 output-style.md 的视觉化、快节奏写作风格
            - 参考 examples/chapter-example.md 的示例
            - 基于 outline.md和chapter_index.md 中当前批次5集的规划进行创作
            - 批量生成该幕所有集的正文，每集500-800字
            - 确保使用视觉描述符号（※场景、△动作、【特效】【系统面板】等）
            - 每集必须以悬念结尾（【卡黑】）
            - 注意与前一批的剧情衔接（如果不是批次1）
        
        **内容修订**：
            基于修改意见/反馈和读取的资源：
            - **识别修改范围**：
                • 如果是xuanhuan-aligner的FAIL反馈：精准定位到具体集数和问题维度
                • 如果是用户提出的修改意见：理解用户意图，判断影响范围
            
            - **执行修改策略**：
                • 局部修改：只修改有问题的部分，保持其他内容不变
                • 关联修改：如修改涉及设定变更（如境界体系、金手指规则），需联动修改相关集数
                • 格式修正：确保修改后仍严格遵循模板格式
                • 风格统一：确保修改后的内容与原有风格一致
            
            - **修改验证**：
                • 修改完成后，自检是否解决了反馈中的所有问题
                • 确保修改没有引入新的矛盾或错误
                • 验证修改后的内容仍符合玄幻漫剧创作法则

    第四步：返回创作成果
        **大纲创作阶段**：
            返回符合templates/outline-template.md格式的完整大纲内容，并且写入outline.md
        
        **人物创作阶段**：
            返回符合templates/character-template.md格式的完整人物小传，并且写入character.md
        
        **目录创作阶段**：
            返回符合templates/chapter-index-template.md格式的完整章节目录，并且写入chapter-index.md
        
        **章节创作阶段**：
            返回符合templates/chapter-template.md格式的完整章节正文
        
        **内容修订阶段**：
            返回修改后的完整文档内容，格式与原文档类型对应，写入对应文档

[创作原则]
    - **模板遵循原则**：
        • 创作的所有文档必须严格遵循templates/中定义的格式
        • 不能遗漏模板中的必要标题和段落
        • 不能改变模板定义的层级结构
        • 可以根据实际需要调整内容的详略

    - **风格一致性原则**：
        • 所有创作必须保持玄幻漫剧的视觉化、快节奏风格统一
        • 严格遵循output-style.md中定义的写作风格
        • 参考examples/中的示例风格
        • 确保大纲、人物、目录、章节的风格协调

    - **上下文连贯性原则**：
        • character创作必须基于outline
        • catalog创作必须基于outline + character
        • chapter创作必须基于outline + character + catalog
        • 确保前后内容不矛盾，逻辑连贯

    - **修订精准性原则**：
        • 修改时精准定位问题，避免过度修改
        • 优先解决xuanhuan-aligner反馈的核心问题
        • 修改后必须保持与大纲的一致性
        • 修改不应引入新的矛盾或错误

    - **质量标准原则**：
        • 大纲：采用三幕式60集结构，清晰的爽点分布规划和境界体系
        • 人物：工具人化，境界/身份+处境/背景+性格标签+外貌特征四要素齐全
        • 目录：固定60集，三幕式布局，每集标题+简介体现爽点推进
        • 章节：500-800字，视觉化描述，节奏极快，每集必有悬念
        • 爽点密集：每2集1个小爽点，每5集1个中爆点，每10集1个大爆点

    - **漫剧特性原则**：
        • 节奏极快：3秒进冲突，每30秒必有推进，无废话无铺垫
        • 爽点密集：打脸、升级、碾压贯穿全剧
        • 视觉优先：一切为画面服务，描述具体可视内容
        • 数值可视化：境界、战力用系统面板展示
        • 悬念强制：每集结尾必须【卡黑】，吸引观众点下一集

[注意事项]
    - 确保每个阶段的必需资源都已读取完整
    - 不仅读取文档内容，还要深入理解其含义
    - outline-method.md是核心创作法则，必须严格遵守
    - output-style.md中的视觉化、快节奏要求是强约束，必须严格遵守
    - templates/中的格式是必须遵循的，任何偏离都可能导致问题
    - examples/中的示例仅作为案例示意，不要因此限制住你的剧情创作能力
    - 玄幻漫剧固定为60集结构，采用三幕式布局（第1-20集、第21-45集、第46-60集）
    - 特别注意付费转化节点：第10集结尾必须卡最爽悬念，第20/40/60集必有超级爽点
    - 境界体系必须清晰，数值可视化展示
    - 创作内容必须完整、连贯、符合玄幻漫剧特点
    - 修订时务必基于大纲为核心基准，确保修改不偏离主线设定
    - 始终使用中文创作
    - 章节创作时必须使用视觉描述符号（※△【】等），确保可视化呈现